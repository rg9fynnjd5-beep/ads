import { Module } from '@nestjs/common';
import { ConfigModule } from './common/config.module';
import { PrismaModule } from './common/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { ServersModule } from './modules/servers/servers.module';
import { EggsModule } from './modules/eggs/eggs.module';
import { NodesModule } from './modules/nodes/nodes.module';
import { DiscordModule } from './modules/discord/discord.module';
import { WebsocketModule } from './modules/websocket/websocket.module';

@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    AuthModule,
    UsersModule,
    ServersModule,
    EggsModule,
    NodesModule,
    DiscordModule,
    WebsocketModule,
  ],
})
export class AppModule {}
