export interface JwtPayload {
  sub: string;
  email: string;
  role: string;
}

export interface ServerStatus {
  id: string;
  state: string;
  uptime: number;
  cpu: number;
  memory: number;
  disk: number;
  players?: number;
}
