import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';

@Injectable()
export class DiscordService implements OnModuleInit {
  private readonly logger = new Logger(DiscordService.name);
  private client: any = null;

  constructor(private prisma: PrismaService) {}

  async onModuleInit() {
    // Discord bot initialization is handled by the separate discord-bot service
    // This module provides the API endpoints for Discord integration
  }

  async getLinkedUsers() {
    return this.prisma.user.findMany({
      where: { discordId: { not: null } },
      select: { id: true, username: true, discordId: true },
    });
  }

  async linkUser(userId: string, discordId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { discordId },
    });
  }

  async unlinkUser(userId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { discordId: null },
    });
  }

  async getServerStatus(serverId: string) {
    const server = await this.prisma.server.findUnique({
      where: { id: serverId },
      include: { user: { select: { discordId: true, username: true } } },
    });
    return server;
  }

  async notifyServerStatus(serverId: string, status: string) {
    this.logger.log(`Server ${serverId} status: ${status}`);
    // In production, send Discord DM/webhook to server owner
  }
}
