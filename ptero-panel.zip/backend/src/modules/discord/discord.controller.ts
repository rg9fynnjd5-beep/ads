import { Controller, Get, Post, Delete, Param, Body, UseGuards, Req } from '@nestjs/common';
import { DiscordService } from './discord.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@Controller('discord')
export class DiscordController {
  constructor(private discordService: DiscordService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Get('users')
  async getLinkedUsers() {
    return this.discordService.getLinkedUsers();
  }

  @UseGuards(JwtAuthGuard)
  @Post('link')
  async linkDiscord(@Req() req, @Body('discordId') discordId: string) {
    return this.discordService.linkUser(req.user.sub, discordId);
  }

  @UseGuards(JwtAuthGuard)
  @Delete('unlink')
  async unlinkDiscord(@Req() req) {
    return this.discordService.unlinkUser(req.user.sub);
  }

  @UseGuards(JwtAuthGuard)
  @Get('server/:id')
  async getServerStatus(@Param('id') id: string) {
    return this.discordService.getServerStatus(id);
  }
}
