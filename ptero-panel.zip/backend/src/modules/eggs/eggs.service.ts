import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';

@Injectable()
export class EggsService {
  constructor(private prisma: PrismaService) {}

  async findAll(category?: string) {
    const where = category && category !== 'all' ? { category } : {};
    return this.prisma.egg.findMany({ where, orderBy: { name: 'asc' } });
  }

  async findById(id: string) {
    const egg = await this.prisma.egg.findUnique({ where: { id } });
    if (!egg) throw new NotFoundException('Egg not found');
    return egg;
  }

  async create(data: any) {
    return this.prisma.egg.create({ data });
  }

  async update(id: string, data: any) {
    await this.findById(id);
    return this.prisma.egg.update({ where: { id }, data });
  }

  async delete(id: string) {
    await this.findById(id);
    return this.prisma.egg.delete({ where: { id } });
  }

  async importEgg(eggData: any) {
    return this.prisma.egg.create({
      data: {
        name: eggData.name,
        description: eggData.description,
        dockerImage: eggData.docker_image,
        startup: eggData.startup,
        config: eggData.config || {},
        script: eggData.scripts?.installation?.script || {},
        meta: { author: eggData.author, version: eggData.version },
        category: eggData.category || 'general',
      },
    });
  }
}
