import { Controller, Get, Post, Patch, Delete, Param, Body, Query, UseGuards } from '@nestjs/common';
import { EggsService } from './eggs.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@Controller('eggs')
export class EggsController {
  constructor(private eggsService: EggsService) {}

  @Get()
  async findAll(@Query('category') category?: string) {
    return this.eggsService.findAll(category);
  }

  @Get(':id')
  async findById(@Param('id') id: string) {
    return this.eggsService.findById(id);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Post()
  async create(@Body() data: any) {
    return this.eggsService.create(data);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Post('import')
  async import(@Body() data: any) {
    return this.eggsService.importEgg(data);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Patch(':id')
  async update(@Param('id') id: string, @Body() data: any) {
    return this.eggsService.update(id, data);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.eggsService.delete(id);
  }
}
