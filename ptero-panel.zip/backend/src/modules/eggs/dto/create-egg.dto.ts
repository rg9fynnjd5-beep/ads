import { IsString, IsOptional, IsObject } from 'class-validator';

export class CreateEggDto {
  @IsString()
  name: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  dockerImage: string;

  @IsString()
  startup: string;

  @IsObject()
  config: any;

  @IsObject()
  @IsOptional()
  script?: any;

  @IsString()
  @IsOptional()
  category?: string;
}
