import { Controller, Get, Post, Delete, Param, Body, UseGuards, Query, Req } from '@nestjs/common';
import { ServersService } from './servers.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CreateServerDto } from './dto/create-server.dto';

@Controller('servers')
export class ServersController {
  constructor(private serversService: ServersService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN')
  @Get()
  async findAll(@Query('page') page = 1, @Query('limit') limit = 25) {
    return this.serversService.findAll(+page, +limit);
  }

  @UseGuards(JwtAuthGuard)
  @Get('my')
  async findMyServers(@Req() req) {
    return this.serversService.findByUser(req.user.sub);
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id')
  async findById(@Param('id') id: string) {
    return this.serversService.findById(id);
  }

  @UseGuards(JwtAuthGuard)
  @Post()
  async create(@Body() dto: CreateServerDto, @Req() req) {
    return this.serversService.create(dto, req.user.sub);
  }

  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.serversService.delete(id);
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id/stats')
  async getStats(@Param('id') id: string) {
    return this.serversService.getStats(id);
  }

  @UseGuards(JwtAuthGuard)
  @Post(':id/power')
  async powerAction(@Param('id') id: string, @Body('action') action: string) {
    return this.serversService.sendPowerAction(id, action);
  }

  @UseGuards(JwtAuthGuard)
  @Post(':id/command')
  async sendCommand(@Param('id') id: string, @Body('command') command: string) {
    return this.serversService.sendCommand(id, command);
  }
}
