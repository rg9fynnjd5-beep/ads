import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';
import { CreateServerDto } from './dto/create-server.dto';
import { v4 as uuid } from 'uuid';

@Injectable()
export class ServersService {
  constructor(private prisma: PrismaService) {}

  async findAll(page = 1, limit = 25) {
    const skip = (page - 1) * limit;
    const [data, total] = await Promise.all([
      this.prisma.server.findMany({
        skip,
        take: limit,
        include: { egg: { select: { name: true } }, node: { select: { name: true } } },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.server.count(),
    ]);
    return { data, total, page, limit };
  }

  async findByUser(userId: string) {
    return this.prisma.server.findMany({
      where: { userId },
      include: { egg: { select: { name: true } }, node: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findById(id: string) {
    const server = await this.prisma.server.findUnique({
      where: { id },
      include: { egg: true, node: true, user: { select: { id: true, username: true } } },
    });
    if (!server) throw new NotFoundException('Server not found');
    return server;
  }

  async create(dto: CreateServerDto, userId: string) {
    const egg = await this.prisma.egg.findUnique({ where: { id: dto.eggId } });
    if (!egg) throw new BadRequestException('Egg not found');

    const node = await this.prisma.node.findUnique({ where: { id: dto.nodeId } });
    if (!node) throw new BadRequestException('Node not found');

    const identifier = this.generateIdentifier();

    const server = await this.prisma.server.create({
      data: {
        name: dto.name,
        description: dto.description,
        memory: dto.memory,
        disk: dto.disk,
        cpu: dto.cpu,
        dockerImage: egg.dockerImage,
        startup: egg.startup,
        environment: dto.environment || {},
        identifier,
        userId,
        nodeId: dto.nodeId,
        eggId: dto.eggId,
        state: 'INSTALLING',
      },
    });

    return server;
  }

  async updateState(id: string, state: string) {
    return this.prisma.server.update({
      where: { id },
      data: { state: state as any },
    });
  }

  async delete(id: string) {
    await this.findById(id);
    return this.prisma.server.delete({ where: { id } });
  }

  async getStats(id: string) {
    const server = await this.findById(id);
    // In production, this would query the daemon for live stats
    return { cpu: 0, memory: 0, disk: 0, state: server.state };
  }

  async sendPowerAction(id: string, action: string) {
    const server = await this.findById(id);
    // In production, send command to Wings daemon
    const validActions = ['start', 'stop', 'restart', 'kill'];
    if (!validActions.includes(action)) throw new BadRequestException(`Invalid action: ${action}`);
    return { message: `Power action '${action}' sent to server`, serverId: id };
  }

  async sendCommand(id: string, command: string) {
    const server = await this.findById(id);
    // In production, send command via WebSocket to daemon
    return { message: 'Command sent', serverId: id };
  }

  private generateIdentifier(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
}
