import { IsString, IsNumber, IsOptional, IsObject, Min, Max } from 'class-validator';

export class CreateServerDto {
  @IsString()
  name: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsNumber()
  @Min(128)
  memory: number;

  @IsNumber()
  @Min(512)
  disk: number;

  @IsNumber()
  @Min(0)
  @Max(100)
  cpu: number;

  @IsString()
  eggId: string;

  @IsString()
  nodeId: string;

  @IsObject()
  @IsOptional()
  environment?: Record<string, string>;
}
