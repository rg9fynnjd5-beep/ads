import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({
  cors: { origin: '*' },
  namespace: '/ws',
})
export class WebsocketGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private connectedClients = new Map<string, Socket>();

  handleConnection(client: Socket) {
    const token = client.handshake.auth?.token || client.handshake.query?.token;
    if (!token) {
      client.disconnect();
      return;
    }
    // Validate JWT token here
    this.connectedClients.set(client.id, client);
    client.join(`user:${client.handshake.auth?.userId || 'anonymous'}`);
  }

  handleDisconnect(client: Socket) {
    this.connectedClients.delete(client.id);
  }

  @SubscribeMessage('subscribe:server')
  handleSubscribeServer(@ConnectedSocket() client: Socket, @MessageBody() serverId: string) {
    client.join(`server:${serverId}`);
    return { event: 'subscribed', data: { serverId } };
  }

  @SubscribeMessage('unsubscribe:server')
  handleUnsubscribeServer(@ConnectedSocket() client: Socket, @MessageBody() serverId: string) {
    client.leave(`server:${serverId}`);
  }

  sendServerStatus(serverId: string, status: any) {
    this.server?.to(`server:${serverId}`).emit('server:status', status);
  }

  sendServerStats(serverId: string, stats: any) {
    this.server?.to(`server:${serverId}`).emit('server:stats', stats);
  }

  sendServerLog(serverId: string, logLine: string) {
    this.server?.to(`server:${serverId}`).emit('server:log', logLine);
  }

  sendNotification(userId: string, notification: any) {
    this.server?.to(`user:${userId}`).emit('notification', notification);
  }
}
