import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';
import { v4 as uuid } from 'uuid';

@Injectable()
export class NodesService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.node.findMany({ orderBy: { name: 'asc' } });
  }

  async findById(id: string) {
    const node = await this.prisma.node.findUnique({
      where: { id },
      include: { servers: { select: { id: true, name: true, state: true } } },
    });
    if (!node) throw new NotFoundException('Node not found');
    return node;
  }

  async create(data: any) {
    const daemonToken = uuid();
    return this.prisma.node.create({
      data: { ...data, daemonToken },
    });
  }

  async update(id: string, data: any) {
    await this.findById(id);
    return this.prisma.node.update({ where: { id }, data });
  }

  async delete(id: string) {
    await this.findById(id);
    return this.prisma.node.delete({ where: { id } });
  }

  async getNodeUsage(id: string) {
    const node = await this.prisma.node.findUnique({
      where: { id },
      include: { servers: true },
    });
    if (!node) throw new NotFoundException('Node not found');

    const usedMemory = node.servers.reduce((sum, s) => sum + s.memory, 0);
    const usedDisk = node.servers.reduce((sum, s) => sum + s.disk, 0);

    return {
      totalMemory: node.memory,
      usedMemory,
      availableMemory: node.memory - usedMemory,
      totalDisk: node.disk,
      usedDisk,
      availableDisk: node.disk - usedDisk,
      serverCount: node.servers.length,
    };
  }
}
