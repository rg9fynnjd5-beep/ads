import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const adminPassword = await bcrypt.hash('admin123', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@panel.com' },
    update: {},
    create: {
      email: 'admin@panel.com',
      username: 'admin',
      password: adminPassword,
      role: 'ADMIN',
    },
  });

  const node = await prisma.node.upsert({
    where: { name: 'Main Node' },
    update: {},
    create: {
      name: 'Main Node',
      fqdn: 'localhost',
      port: 8080,
      memory: 16384,
      disk: 102400,
      daemonToken: 'dev-daemon-token',
    },
  });

  const minecraftEgg = await prisma.egg.upsert({
    where: { id: 'mc-java' },
    update: {},
    create: {
      id: 'mc-java',
      name: 'Minecraft Java Edition',
      description: 'Minecraft Java Edition server using PaperMC',
      dockerImage: 'ghcr.io/pterodactyl/yolks:java_17',
      startup: 'java -Xms${MEMORY}M -Xmx${MEMORY}M -jar server.jar',
      config: {
        files: { 'server.properties': { parser: 'properties', find: {} } },
        logs: { directory: 'logs', file: 'latest.log' },
      },
      category: 'minecraft',
    },
  });

  console.log('Seed complete:', { admin: admin.email, node: node.name, egg: minecraftEgg.name });
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
