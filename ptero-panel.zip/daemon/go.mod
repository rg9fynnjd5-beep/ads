module github.com/ptero-panel/daemon

go 1.21

require (
	github.com/docker/docker v24.0.0+incompatible
	github.com/gorilla/mux v1.8.1
	github.com/gorilla/websocket v1.5.0
	github.com/shirou/gopsutil/v3 v3.23.0
	gopkg.in/yaml.v3 v3.0.1
)
