package config

import (
	"os"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Port        int    `yaml:"port"`
	DaemonToken string `yaml:"daemon_token"`
	PanelURL    string `yaml:"panel_url"`
	DataDir     string `yaml:"data_dir"`
	MaxServers  int    `yaml:"max_servers"`
}

func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return defaultConfig(), nil
	}

	cfg := &Config{}
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, err
	}

	if cfg.Port == 0 {
		cfg.Port = 8080
	}
	if cfg.DataDir == "" {
		cfg.DataDir = "./data"
	}
	if cfg.MaxServers == 0 {
		cfg.MaxServers = 10
	}

	return cfg, nil
}

func defaultConfig() *Config {
	return &Config{
		Port:       8080,
		DaemonToken: "dev-daemon-token",
		PanelURL:    "http://localhost:3000",
		DataDir:     "./data",
		MaxServers:  10,
	}
}
