package server

import (
	"fmt"
	"log"
	"os/exec"
	"sync"
	"time"

	"github.com/ptero-panel/daemon/internal/config"
)

type ServerInstance struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	State     string    `json:"state"`
	PID       int       `json:"pid"`
	Memory    int       `json:"memory"`
	Disk      int       `json:"disk"`
	CPU       int       `json:"cpu"`
	Startup   string    `json:"startup"`
	Image     string    `json:"image"`
	CreatedAt time.Time `json:"created_at"`
	cmd       *exec.Cmd
}

type SystemStats struct {
	CPU        float64 `json:"cpu"`
	Memory     float64 `json:"memory"`
	Disk       float64 `json:"disk"`
	Uptime     float64 `json:"uptime"`
	GoRoutines int     `json:"go_routines"`
}

type Manager struct {
	mu      sync.RWMutex
	servers map[string]*ServerInstance
	config  *config.Config
	subs    map[string][]chan string
}

func NewManager(cfg *config.Config) *Manager {
	return &Manager{
		servers: make(map[string]*ServerInstance),
		config:  cfg,
		subs:    make(map[string][]chan string),
	}
}

func (m *Manager) ListServers() []*ServerInstance {
	m.mu.RLock()
	defer m.mu.RUnlock()
	list := make([]*ServerInstance, 0, len(m.servers))
	for _, s := range m.servers {
		list = append(list, s)
	}
	return list
}

func (m *Manager) GetServer(id string) *ServerInstance {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.servers[id]
}

func (m *Manager) AddServer(id, name, startup, image string, memory, disk, cpu int) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.servers[id] = &ServerInstance{
		ID:        id,
		Name:      name,
		State:     "OFFLINE",
		Memory:    memory,
		Disk:      disk,
		CPU:       cpu,
		Startup:   startup,
		Image:     image,
		CreatedAt: time.Now(),
	}
	log.Printf("Server %s registered: %s", id, name)
}

func (m *Manager) RemoveServer(id string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if s, ok := m.servers[id]; ok {
		if s.cmd != nil && s.cmd.Process != nil {
			s.cmd.Process.Kill()
		}
		delete(m.servers, id)
	}
}

func (m *Manager) PowerAction(id, action string) error {
	m.mu.Lock()
	s, ok := m.servers[id]
	m.mu.Unlock()

	if !ok {
		return fmt.Errorf("server not found")
	}

	switch action {
	case "start":
		if s.State == "ONLINE" {
			return fmt.Errorf("server already running")
		}
		s.State = "ONLINE"
		log.Printf("Server %s started", id)
	case "stop":
		if s.State == "OFFLINE" {
			return fmt.Errorf("server already stopped")
		}
		if s.cmd != nil && s.cmd.Process != nil {
			s.cmd.Process.Kill()
		}
		s.State = "OFFLINE"
		log.Printf("Server %s stopped", id)
	case "restart":
		if s.cmd != nil && s.cmd.Process != nil {
			s.cmd.Process.Kill()
		}
		s.State = "ONLINE"
		log.Printf("Server %s restarted", id)
	case "kill":
		if s.cmd != nil && s.cmd.Process != nil {
			s.cmd.Process.Kill()
		}
		s.State = "OFFLINE"
		log.Printf("Server %s killed", id)
	default:
		return fmt.Errorf("unknown action: %s", action)
	}

	m.broadcast(id, fmt.Sprintf("[%s] Server %s: %s", time.Now().Format(time.RFC3339), id, action))
	return nil
}

func (m *Manager) SendCommand(id, command string) error {
	m.mu.RLock()
	s, ok := m.servers[id]
	m.mu.RUnlock()

	if !ok {
		return fmt.Errorf("server not found")
	}

	if s.State != "ONLINE" {
		return fmt.Errorf("server is not running")
	}

	if s.cmd != nil && s.cmd.Process != nil {
		// In production, write to stdin of the process
		log.Printf("Command sent to %s: %s", id, command)
	}

	m.broadcast(id, fmt.Sprintf("> %s", command))
	return nil
}

func (m *Manager) InstallServer(id, eggName, startup, image string) error {
	m.mu.Lock()
	s, ok := m.servers[id]
	if !ok {
		s = &ServerInstance{
			ID:        id,
			State:     "INSTALLING",
			CreatedAt: time.Now(),
		}
		m.servers[id] = s
	}
	s.State = "INSTALLING"
	s.Startup = startup
	s.Image = image
	m.mu.Unlock()

	log.Printf("Installing server %s with egg %s", id, eggName)

	go func() {
		time.Sleep(2 * time.Second) // Simulate installation
		m.mu.Lock()
		s.State = "OFFLINE"
		m.mu.Unlock()
		log.Printf("Server %s installation complete", id)
		m.broadcast(id, "[system] Installation complete")
	}()

	return nil
}

func (m *Manager) Subscribe(id string, ch chan string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.subs[id] = append(m.subs[id], ch)
}

func (m *Manager) Unsubscribe(id string, ch chan string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	subs := m.subs[id]
	for i, sub := range subs {
		if sub == ch {
			m.subs[id] = append(subs[:i], subs[i+1:]...)
			break
		}
	}
}

func (m *Manager) broadcast(id, message string) {
	m.mu.RLock()
	subs := m.subs[id]
	m.mu.RUnlock()

	for _, ch := range subs {
		select {
		case ch <- message:
		default:
		}
	}
}

func (m *Manager) GetSystemStats() *SystemStats {
	return &SystemStats{
		CPU:        45.2,
		Memory:     62.8,
		Disk:       38.5,
		Uptime:     time.Now().Sub(time.Now().Add(-24 * time.Hour)).Seconds(),
		GoRoutines: 12,
	}
}

func (m *Manager) Shutdown() {
	m.mu.Lock()
	defer m.mu.Unlock()

	for id, s := range m.servers {
		if s.cmd != nil && s.cmd.Process != nil {
			s.cmd.Process.Kill()
		}
		s.State = "OFFLINE"
		log.Printf("Server %s stopped during shutdown", id)
	}
}
