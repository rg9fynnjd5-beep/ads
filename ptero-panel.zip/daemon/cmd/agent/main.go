package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/gorilla/mux"
	"github.com/gorilla/websocket"
	"github.com/ptero-panel/daemon/internal/config"
	"github.com/ptero-panel/daemon/internal/server"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

func main() {
	configPath := flag.String("config", "config.yml", "path to config file")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	manager := server.NewManager(cfg)

	r := mux.NewRouter()
	api := r.PathPrefix("/api/v1").Subrouter()

	api.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			token := r.Header.Get("Authorization")
			if token != "Bearer "+cfg.DaemonToken {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}
			next.ServeHTTP(w, r)
		})
	})

	api.HandleFunc("/servers", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet {
			servers := manager.ListServers()
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]interface{}{"data": servers})
		}
	}).Methods("GET")

	api.HandleFunc("/servers/{id}", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		s := manager.GetServer(vars["id"])
		if s == nil {
			http.Error(w, `{"error":"server not found"}`, http.StatusNotFound)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"data": s})
	}).Methods("GET")

	api.HandleFunc("/servers/{id}/power", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		if r.Method == http.MethodPost {
			action := r.URL.Query().Get("action")
			if action == "" {
				action = "start"
			}
			err := manager.PowerAction(vars["id"], action)
			if err != nil {
				http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]string{"message": fmt.Sprintf("power action %s sent", action)})
		}
	}).Methods("POST")

	api.HandleFunc("/servers/{id}/command", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		if r.Method == http.MethodPost {
			cmd := r.URL.Query().Get("command")
			if cmd == "" {
				cmd = "help"
			}
			err := manager.SendCommand(vars["id"], cmd)
			if err != nil {
				http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]string{"message": "command sent"})
		}
	}).Methods("POST")

	api.HandleFunc("/servers/{id}/install", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		if r.Method == http.MethodPost {
			err := manager.InstallServer(vars["id"], "paper", "java -jar server.jar", "ghcr.io/pterodactyl/yolks:java_17")
			if err != nil {
				http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]string{"message": "installation started"})
		}
	}).Methods("POST")

	r.HandleFunc("/ws/console/{id}", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		conn, err := upgrader.Upgrade(w, r, nil)
		if err != nil {
			log.Printf("WebSocket upgrade error: %v", err)
			return
		}
		defer conn.Close()

		s := manager.GetServer(vars["id"])
		if s == nil {
			conn.WriteMessage(websocket.TextMessage, []byte(`{"error":"server not found"}`))
			return
		}

		ch := make(chan string, 100)
		manager.Subscribe(vars["id"], ch)
		defer manager.Unsubscribe(vars["id"], ch)

		done := make(chan struct{})

		go func() {
			defer close(done)
			for {
				_, msg, err := conn.ReadMessage()
				if err != nil {
					return
				}
				manager.SendCommand(vars["id"], string(msg))
			}
		}()

		for {
			select {
			case line := <-ch:
				err := conn.WriteMessage(websocket.TextMessage, []byte(line))
				if err != nil {
					return
				}
			case <-done:
				return
			}
		}
	})

	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"status": "ok", "version": "1.0.0"})
	}).Methods("GET")

	r.HandleFunc("/stats", func(w http.ResponseWriter, r *http.Request) {
		stats := manager.GetSystemStats()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"data": stats})
	}).Methods("GET")

	addr := fmt.Sprintf(":%d", cfg.Port)
	log.Printf("Daemon starting on %s", addr)

	httpServer := &http.Server{
		Addr:    addr,
		Handler: r,
	}

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigChan
		log.Println("Shutting down...")
		manager.Shutdown()
		httpServer.Close()
	}()

	if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("Server error: %v", err)
	}
}
