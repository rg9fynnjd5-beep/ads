'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Server, LayoutDashboard, Settings, Users, Disc, Terminal, LogOut } from 'lucide-react';

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/servers', label: 'Servers', icon: Server },
  { href: '/dashboard/console', label: 'Console', icon: Terminal },
];

const adminItems = [
  { href: '/dashboard/admin/nodes', label: 'Nodes', icon: Disc },
  { href: '/dashboard/admin/eggs', label: 'Eggs', icon: Server },
  { href: '/dashboard/admin/users', label: 'Users', icon: Users },
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-surface-800 border-r border-surface-700 flex flex-col">
      <div className="p-4 border-b border-surface-700">
        <Link href="/dashboard" className="flex items-center gap-2">
          <Server className="w-6 h-6 text-primary-500" />
          <span className="font-bold text-lg">Panel</span>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        <p className="text-xs font-medium text-surface-500 uppercase tracking-wider mb-2">General</p>
        {navItems.map(({ href, label, icon: Icon }) => (
          <Link key={href} href={href}
            className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
              pathname === href ? 'bg-primary-600/20 text-primary-400' : 'text-surface-300 hover:bg-surface-700'
            }`}>
            <Icon className="w-4 h-4" /> {label}
          </Link>
        ))}

        {user?.role === 'ADMIN' && (
          <>
            <p className="text-xs font-medium text-surface-500 uppercase tracking-wider mt-6 mb-2">Administration</p>
            {adminItems.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                  pathname.startsWith(href) ? 'bg-primary-600/20 text-primary-400' : 'text-surface-300 hover:bg-surface-700'
                }`}>
                <Icon className="w-4 h-4" /> {label}
              </Link>
            ))}
          </>
        )}
      </nav>

      <div className="p-4 border-t border-surface-700">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-sm font-medium">
            {user?.username?.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user?.username}</p>
            <p className="text-xs text-surface-400 truncate">{user?.email}</p>
          </div>
        </div>
        <button onClick={logout} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-surface-400 hover:text-red-400 hover:bg-surface-700 rounded-lg transition-colors">
          <LogOut className="w-4 h-4" /> Sign Out
        </button>
      </div>
    </aside>
  );
}
