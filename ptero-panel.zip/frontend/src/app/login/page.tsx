'use client';
import { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Server } from 'lucide-react';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-900 px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-2 mb-8">
          <Server className="w-8 h-8 text-primary-500" />
          <span className="text-2xl font-bold">Panel</span>
        </div>
        <div className="bg-surface-800 border border-surface-700 rounded-xl p-8">
          <h2 className="text-xl font-semibold mb-6">Sign in to your account</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-surface-400 mb-1">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                className="w-full px-4 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-surface-400 mb-1">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required
                className="w-full px-4 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 rounded-lg font-medium transition-colors">
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>
          <p className="mt-4 text-center text-surface-400 text-sm">
            Don&apos;t have an account? <a href="/register" className="text-primary-400 hover:text-primary-300">Register</a>
          </p>
        </div>
      </div>
    </div>
  );
}
