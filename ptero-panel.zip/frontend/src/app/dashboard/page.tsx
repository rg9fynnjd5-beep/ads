'use client';
import { useState, useEffect } from 'react';
import api from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import { Server, Cpu, HardDrive, Activity } from 'lucide-react';
import { formatBytes } from '@/lib/utils';

export default function DashboardPage() {
  const { user } = useAuth();
  const [servers, setServers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/servers/my').then((res) => setServers(res.data)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const totalResources = servers.reduce((acc, s) => ({ memory: acc.memory + s.memory, disk: acc.disk + s.disk, cpu: acc.cpu + s.cpu }), { memory: 0, disk: 0, cpu: 0 });
  const onlineCount = servers.filter((s) => s.state === 'ONLINE').length;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Welcome, {user?.username}</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Servers', value: servers.length, icon: Server, color: 'text-blue-400' },
          { label: 'Online', value: onlineCount, icon: Activity, color: 'text-green-400' },
          { label: 'Memory', value: formatBytes(totalResources.memory * 1024 * 1024), icon: HardDrive, color: 'text-purple-400' },
          { label: 'CPU', value: `${totalResources.cpu}%`, icon: Cpu, color: 'text-orange-400' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-surface-800 border border-surface-700 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-surface-400">{label}</p>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="text-2xl font-bold">{value}</p>
          </div>
        ))}
      </div>

      <div className="bg-surface-800 border border-surface-700 rounded-xl p-6">
        <h2 className="text-lg font-semibold mb-4">Your Servers</h2>
        {loading ? (
          <div className="flex justify-center py-8"><div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-500"></div></div>
        ) : servers.length === 0 ? (
          <p className="text-surface-400 text-center py-8">No servers yet. Create your first one!</p>
        ) : (
          <div className="space-y-3">
            {servers.map((server) => (
              <a key={server.id} href={`/dashboard/servers/${server.id}`}
                className="flex items-center justify-between p-4 bg-surface-700/50 rounded-lg hover:bg-surface-700 transition-colors">
                <div>
                  <p className="font-medium">{server.name}</p>
                  <p className="text-sm text-surface-400">{server.egg?.name} &middot; {server.node?.name}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-surface-400">{server.memory} MB / {server.disk} MB</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    server.state === 'ONLINE' ? 'bg-green-900/50 text-green-400' :
                    server.state === 'INSTALLING' ? 'bg-yellow-900/50 text-yellow-400' :
                    'bg-red-900/50 text-red-400'
                  }`}>{server.state}</span>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
