'use client';
import { useState, useEffect } from 'react';
import api from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import { Plus, Search } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ServersPage() {
  const { user } = useAuth();
  const [servers, setServers] = useState<any[]>([]);
  const [eggs, setEggs] = useState<any[]>([]);
  const [nodes, setNodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', memory: 1024, disk: 5120, cpu: 100, eggId: '', nodeId: '', environment: '{}' });
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    Promise.all([api.get('/servers/my'), api.get('/eggs'), api.get('/nodes')])
      .then(([s, e, n]) => { setServers(s.data); setEggs(e.data); setNodes(n.data); })
      .catch(() => toast.error('Failed to load data'))
      .finally(() => setLoading(false));
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      const payload = { ...form, environment: JSON.parse(form.environment) };
      await api.post('/servers', payload);
      toast.success('Server created!');
      setShowCreate(false);
      const res = await api.get('/servers/my');
      setServers(res.data);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to create server');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Servers</h1>
        <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg transition-colors">
          <Plus className="w-4 h-4" /> Create Server
        </button>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCreate(false)}>
          <div className="bg-surface-800 border border-surface-700 rounded-xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-lg font-semibold mb-4">Create New Server</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm text-surface-400 mb-1">Name</label>
                <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required
                  className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-surface-400 mb-1">Memory (MB)</label>
                  <input type="number" value={form.memory} onChange={(e) => setForm({ ...form, memory: +e.target.value })} min={128}
                    className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
                </div>
                <div>
                  <label className="block text-sm text-surface-400 mb-1">Disk (MB)</label>
                  <input type="number" value={form.disk} onChange={(e) => setForm({ ...form, disk: +e.target.value })} min={512}
                    className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
                </div>
                <div>
                  <label className="block text-sm text-surface-400 mb-1">CPU (%)</label>
                  <input type="number" value={form.cpu} onChange={(e) => setForm({ ...form, cpu: +e.target.value })} min={0} max={100}
                    className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
                </div>
                <div>
                  <label className="block text-sm text-surface-400 mb-1">Egg</label>
                  <select value={form.eggId} onChange={(e) => setForm({ ...form, eggId: e.target.value })} required
                    className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white">
                    <option value="">Select egg</option>
                    {eggs.map((egg: any) => <option key={egg.id} value={egg.id}>{egg.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm text-surface-400 mb-1">Node</label>
                <select value={form.nodeId} onChange={(e) => setForm({ ...form, nodeId: e.target.value })} required
                  className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white">
                  <option value="">Select node</option>
                  {nodes.map((node: any) => <option key={node.id} value={node.id}>{node.name}</option>)}
                </select>
              </div>
              <div className="flex gap-3 justify-end pt-2">
                <button type="button" onClick={() => setShowCreate(false)} className="px-4 py-2 bg-surface-700 hover:bg-surface-600 rounded-lg transition-colors">Cancel</button>
                <button type="submit" disabled={creating} className="px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 rounded-lg transition-colors">
                  {creating ? 'Creating...' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div></div>
      ) : servers.length === 0 ? (
        <div className="text-center py-12 text-surface-400">
          <Server className="w-16 h-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg mb-2">No servers yet</p>
          <p className="text-sm">Click "Create Server" to deploy your first one.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {servers.map((server) => (
            <a key={server.id} href={`/dashboard/servers/${server.id}`}
              className="flex items-center justify-between p-4 bg-surface-800 border border-surface-700 rounded-xl hover:border-surface-600 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`w-2 h-2 rounded-full ${server.state === 'ONLINE' ? 'bg-green-500' : server.state === 'INSTALLING' ? 'bg-yellow-500' : 'bg-red-500'}`} />
                <div>
                  <p className="font-medium">{server.name}</p>
                  <p className="text-sm text-surface-400">{server.egg?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-sm text-surface-400">
                <span>{server.memory} MB</span>
                <span>{server.disk} MB</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  server.state === 'ONLINE' ? 'bg-green-900/50 text-green-400' : 'bg-red-900/50 text-red-400'
                }`}>{server.state}</span>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
