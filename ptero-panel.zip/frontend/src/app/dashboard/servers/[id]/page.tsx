'use client';
import { useState, useEffect, useRef } from 'react';
import api from '@/lib/api';
import { useParams } from 'next/navigation';
import { Power, PowerOff, RefreshCw, Terminal, Activity, Cpu, HardDrive } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ServerDetailPage() {
  const { id } = useParams();
  const [server, setServer] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [command, setCommand] = useState('');
  const [logs, setLogs] = useState<string[]>([]);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get(`/servers/${id}`).then((res) => setServer(res.data)).catch(() => toast.error('Server not found')).finally(() => setLoading(false));
  }, [id]);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logs]);

  const powerAction = async (action: string) => {
    try {
      await api.post(`/servers/${id}/power`, { action });
      toast.success(`Power action: ${action}`);
    } catch { toast.error('Failed to send power action'); }
  };

  const sendCommand = async () => {
    if (!command.trim()) return;
    try {
      await api.post(`/servers/${id}/command`, { command });
      setLogs((prev) => [...prev, `> ${command}`]);
      setCommand('');
    } catch { toast.error('Failed to send command'); }
  };

  if (loading) return <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div></div>;
  if (!server) return <div className="text-center py-12 text-surface-400">Server not found</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">{server.name}</h1>
          <p className="text-surface-400 text-sm">{server.egg?.name} &middot; {server.node?.name}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => powerAction('start')} className="p-2 bg-green-600/20 text-green-400 hover:bg-green-600/30 rounded-lg transition-colors" title="Start"><Power className="w-4 h-4" /></button>
          <button onClick={() => powerAction('stop')} className="p-2 bg-red-600/20 text-red-400 hover:bg-red-600/30 rounded-lg transition-colors" title="Stop"><PowerOff className="w-4 h-4" /></button>
          <button onClick={() => powerAction('restart')} className="p-2 bg-yellow-600/20 text-yellow-400 hover:bg-yellow-600/30 rounded-lg transition-colors" title="Restart"><RefreshCw className="w-4 h-4" /></button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'CPU', value: `${server.cpu}%`, icon: Cpu, color: 'text-blue-400' },
          { label: 'Memory', value: `${server.memory} MB`, icon: Activity, color: 'text-green-400' },
          { label: 'Disk', value: `${server.disk} MB`, icon: HardDrive, color: 'text-purple-400' },
          { label: 'Status', value: server.state, icon: Terminal, color: server.state === 'ONLINE' ? 'text-green-400' : 'text-red-400' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-surface-800 border border-surface-700 rounded-xl p-4">
            <div className="flex items-center justify-between mb-1">
              <p className="text-sm text-surface-400">{label}</p>
              <Icon className={`w-4 h-4 ${color}`} />
            </div>
            <p className="text-lg font-semibold">{value}</p>
          </div>
        ))}
      </div>

      <div className="bg-surface-800 border border-surface-700 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-surface-700">
          <div className="flex items-center gap-2"><Terminal className="w-4 h-4 text-surface-400" /><span className="text-sm font-medium">Console</span></div>
          <button onClick={() => setLogs([])} className="text-xs text-surface-400 hover:text-white transition-colors">Clear</button>
        </div>
        <div className="h-80 overflow-y-auto p-4 font-mono text-sm bg-surface-950">
          {logs.length === 0 ? (
            <p className="text-surface-500">Waiting for output...</p>
          ) : (
            logs.map((line, i) => <p key={i} className="text-surface-300">{line}</p>)
          )}
          <div ref={logEndRef} />
        </div>
        <div className="flex border-t border-surface-700">
          <input type="text" value={command} onChange={(e) => setCommand(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendCommand()}
            placeholder="Enter command..." className="flex-1 px-4 py-3 bg-surface-800 focus:outline-none text-sm" />
          <button onClick={sendCommand} className="px-4 py-3 bg-primary-600 hover:bg-primary-700 text-sm font-medium transition-colors">Send</button>
        </div>
      </div>
    </div>
  );
}
