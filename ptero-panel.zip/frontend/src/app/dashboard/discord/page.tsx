'use client';
import { useState } from 'react';
import api from '@/lib/api';
import { MessageCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function DiscordPage() {
  const [discordId, setDiscordId] = useState('');
  const [linking, setLinking] = useState(false);

  const linkDiscord = async () => {
    if (!discordId.trim()) return;
    setLinking(true);
    try {
      await api.post('/discord/link', { discordId });
      toast.success('Discord account linked!');
    } catch {
      toast.error('Failed to link Discord');
    } finally {
      setLinking(false);
    }
  };

  const unlinkDiscord = async () => {
    try {
      await api.delete('/discord/unlink');
      toast.success('Discord account unlinked');
    } catch {
      toast.error('Failed to unlink');
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Discord Integration</h1>
      <div className="bg-surface-800 border border-surface-700 rounded-xl p-6 max-w-md">
        <div className="flex items-center gap-3 mb-4">
          <MessageCircle className="w-8 h-8 text-indigo-400" />
          <div>
            <h2 className="font-semibold">Link Discord</h2>
            <p className="text-sm text-surface-400">Receive server notifications on Discord</p>
          </div>
        </div>
        <div className="flex gap-2 mb-3">
          <input type="text" value={discordId} onChange={(e) => setDiscordId(e.target.value)}
            placeholder="Your Discord User ID" className="flex-1 px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-sm" />
          <button onClick={linkDiscord} disabled={linking}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg text-sm transition-colors">Link</button>
        </div>
        <button onClick={unlinkDiscord} className="text-sm text-red-400 hover:text-red-300">Unlink Discord</button>
      </div>
    </div>
  );
}
