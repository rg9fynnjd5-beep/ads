'use client';
import { useState, useEffect } from 'react';
import api from '@/lib/api';
import { Terminal } from 'lucide-react';

export default function ConsolePage() {
  const [servers, setServers] = useState<any[]>([]);
  const [selectedServer, setSelectedServer] = useState<string>('');
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState<string[]>([]);

  useEffect(() => { api.get('/servers/my').then((res) => setServers(res.data)); }, []);

  const executeCommand = async () => {
    if (!command.trim() || !selectedServer) return;
    setOutput((prev) => [...prev, `> ${command}`]);
    try { await api.post(`/servers/${selectedServer}/command`, { command }); } catch {}
    setCommand('');
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Console</h1>
      <div className="bg-surface-800 border border-surface-700 rounded-xl p-4 mb-4">
        <label className="block text-sm text-surface-400 mb-2">Select Server</label>
        <select value={selectedServer} onChange={(e) => setSelectedServer(e.target.value)}
          className="w-full px-3 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white">
          <option value="">Choose a server...</option>
          {servers.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.state})</option>)}
        </select>
      </div>

      {selectedServer && (
        <div className="bg-surface-800 border border-surface-700 rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-surface-700">
            <Terminal className="w-4 h-4 text-surface-400" />
            <span className="text-sm font-medium">Console Output</span>
          </div>
          <div className="h-96 overflow-y-auto p-4 font-mono text-sm bg-surface-950">
            {output.map((line, i) => <p key={i} className="text-surface-300">{line}</p>)}
          </div>
          <div className="flex border-t border-surface-700">
            <input type="text" value={command} onChange={(e) => setCommand(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && executeCommand()}
              placeholder="Enter command..." className="flex-1 px-4 py-3 bg-surface-800 focus:outline-none text-sm" />
            <button onClick={executeCommand} className="px-4 py-3 bg-primary-600 hover:bg-primary-700 text-sm font-medium transition-colors">Send</button>
          </div>
        </div>
      )}
    </div>
  );
}
