'use client';
import { useState, useEffect } from 'react';
import api from '@/lib/api';
import toast from 'react-hot-toast';

export default function AdminEggsPage() {
  const [eggs, setEggs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/eggs').then((res) => setEggs(res.data)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Eggs</h1>
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div></div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {eggs.map((egg) => (
            <div key={egg.id} className="bg-surface-800 border border-surface-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">{egg.name}</h3>
                <span className="px-2 py-1 bg-surface-700 rounded text-xs text-surface-400 capitalize">{egg.category}</span>
              </div>
              <p className="text-sm text-surface-400 mb-3">{egg.description || 'No description'}</p>
              <div className="text-xs text-surface-500">
                <p>Image: {egg.dockerImage?.split('/').pop()}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
