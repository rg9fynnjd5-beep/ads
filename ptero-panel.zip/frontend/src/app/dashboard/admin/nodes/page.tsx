'use client';
import { useState, useEffect } from 'react';
import api from '@/lib/api';
import toast from 'react-hot-toast';

export default function AdminNodesPage() {
  const [nodes, setNodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/nodes').then((res) => setNodes(res.data)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const deleteNode = async (id: string) => {
    if (!confirm('Delete this node?')) return;
    try { await api.delete(`/nodes/${id}`); setNodes((prev) => prev.filter((n) => n.id !== id)); toast.success('Node deleted'); } catch { toast.error('Failed'); }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Nodes</h1>
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div></div>
      ) : (
        <div className="bg-surface-800 border border-surface-700 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-surface-700 text-sm text-surface-400">
                <th className="text-left px-4 py-3">Name</th>
                <th className="text-left px-4 py-3">FQDN</th>
                <th className="text-left px-4 py-3">Memory</th>
                <th className="text-left px-4 py-3">Disk</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-right px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {nodes.map((node) => (
                <tr key={node.id} className="border-b border-surface-700/50 hover:bg-surface-700/30">
                  <td className="px-4 py-3 font-medium">{node.name}</td>
                  <td className="px-4 py-3 text-surface-400">{node.fqdn}:{node.port}</td>
                  <td className="px-4 py-3">{node.memory} MB</td>
                  <td className="px-4 py-3">{node.disk} MB</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded text-xs ${node.enabled ? 'bg-green-900/50 text-green-400' : 'bg-red-900/50 text-red-400'}`}>
                      {node.enabled ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => deleteNode(node.id)} className="text-red-400 hover:text-red-300 text-sm">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
