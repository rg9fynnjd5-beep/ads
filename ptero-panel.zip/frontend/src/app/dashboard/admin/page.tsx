'use client';
import { useAuth } from '@/lib/auth-context';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminPage() {
  const { user } = useAuth();
  const router = useRouter();
  useEffect(() => { if (user?.role === 'ADMIN') router.push('/dashboard/admin/nodes'); }, [user, router]);
  return <div className="text-center py-12 text-surface-400">Redirecting...</div>;
}
