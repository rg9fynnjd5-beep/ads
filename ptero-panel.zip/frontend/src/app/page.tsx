'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Server, Terminal, Database, Cpu } from 'lucide-react';

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading) {
      if (user) router.push('/dashboard');
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-surface-900 via-surface-800 to-surface-900">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <nav className="flex justify-between items-center mb-24">
          <div className="flex items-center gap-2">
            <Server className="w-8 h-8 text-primary-500" />
            <span className="text-xl font-bold">Panel</span>
          </div>
          <div className="flex gap-4">
            <a href="/login" className="px-4 py-2 text-surface-300 hover:text-white transition-colors">Login</a>
            <a href="/register" className="px-4 py-2 bg-primary-600 hover:bg-primary-700 rounded-lg transition-colors">Get Started</a>
          </div>
        </nav>

        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary-400 to-purple-400 text-transparent bg-clip-text">
            Game Server Management<br />Made Simple
          </h1>
          <p className="text-xl text-surface-400 max-w-2xl mx-auto">
            Deploy, manage, and monitor your game servers with ease. 
            Supports Minecraft, Rust, CS2, and hundreds more.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {[
            { icon: Server, title: 'One-Click Deploy', desc: 'Deploy game servers in seconds with pre-configured eggs' },
            { icon: Cpu, title: 'Live Monitoring', desc: 'Real-time CPU, memory, and disk usage tracking' },
            { icon: Terminal, title: 'Console Access', desc: 'Full web-based console with command input and live logs' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="bg-surface-800/50 border border-surface-700 rounded-xl p-6 hover:border-surface-600 transition-colors">
              <Icon className="w-10 h-10 text-primary-500 mb-4" />
              <h3 className="text-lg font-semibold mb-2">{title}</h3>
              <p className="text-surface-400">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
