'use client';
import { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Server } from 'lucide-react';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const [form, setForm] = useState({ email: '', username: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    setLoading(true);
    try {
      await register(form.email, form.username, form.password);
      toast.success('Account created!');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-900 px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-2 mb-8">
          <Server className="w-8 h-8 text-primary-500" />
          <span className="text-2xl font-bold">Panel</span>
        </div>
        <div className="bg-surface-800 border border-surface-700 rounded-xl p-8">
          <h2 className="text-xl font-semibold mb-6">Create an account</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            {(['email', 'username', 'password', 'confirmPassword'] as const).map((field) => (
              <div key={field}>
                <label className="block text-sm font-medium text-surface-400 mb-1 capitalize">
                  {field === 'confirmPassword' ? 'Confirm Password' : field}
                </label>
                <input type={field.includes('password') ? 'password' : 'text'} value={form[field]}
                  onChange={(e) => setForm({ ...form, [field]: e.target.value })} required
                  className="w-full px-4 py-2 bg-surface-700 border border-surface-600 rounded-lg focus:outline-none focus:border-primary-500 text-white" />
              </div>
            ))}
            <button type="submit" disabled={loading}
              className="w-full py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 rounded-lg font-medium transition-colors">
              {loading ? 'Creating account...' : 'Create account'}
            </button>
          </form>
          <p className="mt-4 text-center text-surface-400 text-sm">
            Already have an account? <a href="/login" className="text-primary-400 hover:text-primary-300">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  );
}
