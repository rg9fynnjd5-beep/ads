export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(' ');
}

export function getStateColor(state: string): string {
  const colors: Record<string, string> = {
    ONLINE: 'text-green-400',
    OFFLINE: 'text-red-400',
    INSTALLING: 'text-yellow-400',
    SUSPENDED: 'text-orange-400',
    RESTARTING: 'text-blue-400',
  };
  return colors[state] || 'text-gray-400';
}
