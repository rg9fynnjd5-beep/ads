const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const API_URL = process.env.PANEL_API_URL || 'http://localhost:3000';
const API_KEY = process.env.PANEL_API_KEY;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('servers')
    .setDescription('List your game servers'),
  async execute(interaction) {
    await interaction.deferReply();

    try {
      const res = await axios.get(`${API_URL}/servers/my`, {
        headers: { Authorization: `Bearer ${API_KEY}` },
      });

      const servers = res.data;

      if (!servers || servers.length === 0) {
        return interaction.editReply('You have no servers. Create one in the panel!');
      }

      const embed = new EmbedBuilder()
        .setTitle('Your Servers')
        .setColor(0x3b82f6)
        .setTimestamp();

      servers.forEach((server) => {
        embed.addFields({
          name: `${server.state === 'ONLINE' ? '🟢' : '🔴'} ${server.name}`,
          value: `**Type:** ${server.egg?.name || 'Unknown'}\n**Node:** ${server.node?.name || 'Unknown'}\n**Resources:** ${server.memory}MB RAM / ${server.disk}MB Disk\n**Status:** ${server.state}`,
          inline: true,
        });
      });

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Error fetching servers:', error.message);
      await interaction.editReply('Failed to fetch servers. Is the panel running?');
    }
  },
};
