const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel')
    .setDescription('Get panel information and links'),
  async execute(interaction) {
    const panelUrl = process.env.PANEL_API_URL || 'http://localhost:3000';

    const embed = new EmbedBuilder()
      .setTitle('Game Server Panel')
      .setDescription('Manage your game servers from anywhere')
      .setColor(0x3b82f6)
      .addFields(
        { name: '🌐 Panel URL', value: panelUrl, inline: true },
        { name: '👤 Register', value: `${panelUrl}/register`, inline: true },
        { name: '🔑 Login', value: `${panelUrl}/login`, inline: true },
        { name: '📋 Commands', value: '`/servers` - List servers\n`/server <id>` - View server details\n`/server <id> start/stop/restart` - Control server\n`/ping` - Check bot status', inline: false },
      )
      .setFooter({ text: 'Game Server Panel Bot' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
