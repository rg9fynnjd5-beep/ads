const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const API_URL = process.env.PANEL_API_URL || 'http://localhost:3000';
const API_KEY = process.env.PANEL_API_KEY;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server')
    .setDescription('View or manage a specific server')
    .addStringOption((option) =>
      option.setName('id')
        .setDescription('Server ID')
        .setRequired(true))
    .addStringOption((option) =>
      option.setName('action')
        .setDescription('Action to perform')
        .addChoices(
          { name: 'Start', value: 'start' },
          { name: 'Stop', value: 'stop' },
          { name: 'Restart', value: 'restart' },
          { name: 'Status', value: 'status' },
        )),
  async execute(interaction) {
    const serverId = interaction.options.getString('id');
    const action = interaction.options.getString('action') || 'status';

    await interaction.deferReply();

    try {
      if (action === 'status') {
        const res = await axios.get(`${API_URL}/servers/${serverId}`, {
          headers: { Authorization: `Bearer ${API_KEY}` },
        });

        const server = res.data;

        const embed = new EmbedBuilder()
          .setTitle(server.name)
          .setColor(server.state === 'ONLINE' ? 0x22c55e : 0xef4444)
          .addFields(
            { name: 'Status', value: server.state, inline: true },
            { name: 'Type', value: server.egg?.name || 'Unknown', inline: true },
            { name: 'Node', value: server.node?.name || 'Unknown', inline: true },
            { name: 'Memory', value: `${server.memory} MB`, inline: true },
            { name: 'Disk', value: `${server.disk} MB`, inline: true },
            { name: 'CPU', value: `${server.cpu}%`, inline: true },
          )
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
      } else {
        await axios.post(`${API_URL}/servers/${serverId}/power`, { action }, {
          headers: { Authorization: `Bearer ${API_KEY}` },
        });

        const embed = new EmbedBuilder()
          .setTitle('Power Action')
          .setDescription(`Successfully sent **${action}** to server \`${serverId}\``)
          .setColor(0x22c55e)
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
      }
    } catch (error) {
      console.error('Error:', error.message);
      await interaction.editReply(`Failed to ${action} server. Error: ${error.response?.data?.message || error.message}`);
    }
  },
};
