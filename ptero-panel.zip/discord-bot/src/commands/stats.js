const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const API_URL = process.env.PANEL_API_URL || 'http://localhost:3000';
const API_KEY = process.env.PANEL_API_KEY;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View panel statistics'),
  async execute(interaction) {
    await interaction.deferReply();

    try {
      const [serversRes, usersRes] = await Promise.all([
        axios.get(`${API_URL}/servers`, { headers: { Authorization: `Bearer ${API_KEY}` } }).catch(() => ({ data: { data: [], total: 0 } })),
        axios.get(`${API_URL}/users`, { headers: { Authorization: `Bearer ${API_KEY}` } }).catch(() => ({ data: { data: [], total: 0 } })),
      ]);

      const servers = serversRes.data.data || [];
      const totalUsers = usersRes.data.total || 0;
      const onlineServers = servers.filter(s => s.state === 'ONLINE').length;
      const totalMemory = servers.reduce((acc, s) => acc + (s.memory || 0), 0);
      const totalDisk = servers.reduce((acc, s) => acc + (s.disk || 0), 0);

      const embed = new EmbedBuilder()
        .setTitle('Panel Statistics')
        .setColor(0x3b82f6)
        .addFields(
          { name: 'Total Servers', value: servers.length.toString(), inline: true },
          { name: 'Online', value: onlineServers.toString(), inline: true },
          { name: 'Total Users', value: totalUsers.toString(), inline: true },
          { name: 'Total Memory', value: `${(totalMemory / 1024).toFixed(1)} GB`, inline: true },
          { name: 'Total Disk', value: `${(totalDisk / 1024).toFixed(1)} GB`, inline: true },
        )
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error('Error fetching stats:', error.message);
      await interaction.editReply('Failed to fetch panel statistics.');
    }
  },
};
