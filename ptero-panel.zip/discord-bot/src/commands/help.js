const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show available commands'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Available Commands')
      .setColor(0x3b82f6)
      .addFields(
        { name: '🎮 `/servers`', value: 'List all your game servers' },
        { name: '🖥️ `/server <id> [action]`', value: 'View server details or run start/stop/restart' },
        { name: '📊 `/stats`', value: 'View panel statistics' },
        { name: '🏓 `/ping`', value: 'Check bot latency' },
        { name: '🌐 `/panel`', value: 'Panel information and links' },
      )
      .setFooter({ text: 'Game Server Panel Bot' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
